// AD.cpp : implementation file
//

#include "pch.h"
#include "sokoba.h"
#include "AD.h"
#include "afxdialogex.h"


// AD dialog

IMPLEMENT_DYNAMIC(AD, CDialogEx)

AD::AD(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_AD, pParent)
{

}

AD::~AD()
{
}

void AD::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(AD, CDialogEx)
	ON_STN_CLICKED(IDC_PICTURE, &AD::OnStnClickedPicture)
	ON_BN_CLICKED(IDC_BUTTON2, &AD::OnBnClickedButton2)
END_MESSAGE_MAP()


// AD message handlers


void AD::OnStnClickedPicture()
{
	// TODO: Add your control notification handler code here
}


void AD::OnBnClickedButton2()
{
	AD ad;
	ad.DoModal();
}


BOOL AD::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Add your specialized code here and/or call the base class
	//cs.cx =200; // size
	//cs.cy = 200; 
	cs.x = 0;//500 - leave; // position
	cs.y = 0;// +leave;
	leave += 1000;
	return CDialogEx::PreCreateWindow(cs);
}
