#pragma once


// AD dialog

class AD : public CDialogEx
{
	DECLARE_DYNAMIC(AD)

public:
	AD(CWnd* pParent = nullptr);   // standard constructor
	virtual ~AD();

// Dialog Data
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_AD };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnStnClickedPicture();
	afx_msg void OnBnClickedButton2();
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	int leave;
};
