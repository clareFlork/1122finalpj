// CLineWidthDialog.cpp : implementation file
//

#include "pch.h"
#include "sokoba.h"
#include "CLineWidthDialog.h"
#include "afxdialogex.h"


// CLineWidthDialog dialog

IMPLEMENT_DYNAMIC(CLineWidthDialog, CDialogEx)

CLineWidthDialog::CLineWidthDialog(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_AD, pParent)
{

}

CLineWidthDialog::~CLineWidthDialog()
{
}

void CLineWidthDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CLineWidthDialog, CDialogEx)
END_MESSAGE_MAP()


// CLineWidthDialog message handlers
