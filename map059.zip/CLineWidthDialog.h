#pragma once


// CLineWidthDialog dialog

class CLineWidthDialog : public CDialogEx
{
	DECLARE_DYNAMIC(CLineWidthDialog)

public:
	CLineWidthDialog(CWnd* pParent = nullptr);   // standard constructor
	virtual ~CLineWidthDialog();

// Dialog Data
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_AD };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
};
