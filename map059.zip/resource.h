//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by sokoba.rc
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDR_MAINFRAME                   128
#define IDR_sokobaTYPE                  130
#define IDB_BITMAP7                     322
#define IDB_BITMAP1                     331
#define IDB_BITMAP2                     332
#define IDB_BITMAP3                     333
#define IDB_BITMAP4                     334
#define IDB_BITMAP5                     335
#define IDB_BITMAP6                     336
#define IDD_AD                          337
#define IDB_BITMAP8                     341
#define IDB_BITMAP9                     343
#define IDD_PREVIEW                     344
#define IDD_MUSIC                       344
#define IDC_PICTURE                     1008
#define IDC_BUTTON2                     1010
#define IDB_my                          1011
#define ID_BUTTON32771                  32771
#define NO                              32772
#define ID_ADVANCED                     32773
#define ID_SETTING_SKIP                 32774
#define ID_ADVANCED_TIMER               32775
#define ID_ADVANCED_STOP                32776
#define ID_HELP_PREVIEW                 32777
#define ID_SETTING_BACKGROUND           32778
#define ID_MUSIC_BACKGROUND             32779
#define ID_MUSIC_ELSEMUSIC              32780

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        346
#define _APS_NEXT_COMMAND_VALUE         32781
#define _APS_NEXT_CONTROL_VALUE         1020
#define _APS_NEXT_SYMED_VALUE           310
#endif
#endif
