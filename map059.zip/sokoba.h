
// sokoba.h : main header file for the sokoba application
//
#pragma once

#ifndef __AFXWIN_H__
	#error "include 'pch.h' before including this file for PCH"
#endif

#include "resource.h"       // main symbols


// CsokobaApp:
// See sokoba.cpp for the implementation of this class
//

class CsokobaApp : public CWinApp
{
public:
	CsokobaApp() noexcept;


// Overrides
public:
	virtual BOOL InitInstance();
	virtual int ExitInstance();

// Implementation
	afx_msg void OnAppAbout();
	DECLARE_MESSAGE_MAP()
};

extern CsokobaApp theApp;
