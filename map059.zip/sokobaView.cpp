
// sokobaView.cpp : implementation of the CsokobaView class
//

#include "pch.h"
#include "framework.h"
// SHARED_HANDLERS can be defined in an ATL project implementing preview, thumbnail
// and search filter handlers and allows sharing of document code with that project.
#ifndef SHARED_HANDLERS
#include "sokoba.h"
#endif

#include "sokobaDoc.h"
#include "sokobaView.h"
#include<mmsystem.h>
#include <thread>


#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CsokobaView

IMPLEMENT_DYNCREATE(CsokobaView, CView)

BEGIN_MESSAGE_MAP(CsokobaView, CView)
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, &CView::OnFilePrintPreview)
	ON_WM_KEYDOWN()
	ON_COMMAND(ID_EDIT_UNDO, &CsokobaView::OnEditUndo)
	ON_COMMAND(ID_SETTING_SKIP, &CsokobaView::OnSettingSkip)
	ON_COMMAND(ID_ADVANCED_TIMER, &CsokobaView::OnAdvancedTimer)
	ON_WM_TIMER()
	ON_COMMAND(ID_ADVANCED_STOP, &CsokobaView::OnAdvancedStop)
	ON_COMMAND(ID_MUSIC_BACKGROUND,&CsokobaView::OnMusicBackground)
	ON_COMMAND(ID_MUSIC_ELSEMUSIC, &CsokobaView::OnMusicElsemusic)
END_MESSAGE_MAP()

// CsokobaView construction/destruction

CsokobaView::CsokobaView() noexcept
{
	
	// TODO: add construction code here

}

CsokobaView::~CsokobaView()
{
}

BOOL CsokobaView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

// CsokobaView drawing

#include<memory.h>
#include<string>
#include<iostream>
using namespace std;
char map[100][100] = { 0 };
char map1[100][100] = { 0 };
bool mapD[100][100] = { 0 };
void CsokobaView::OnDraw(CDC* /*pDC*/)
{
	CsokobaDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;
	buildmap();

	// TODO: add draw code for native data here
}


// CsokobaView printing

BOOL CsokobaView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CsokobaView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CsokobaView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}


// CsokobaView diagnostics

#ifdef _DEBUG
void CsokobaView::AssertValid() const
{
	CView::AssertValid();
}

void CsokobaView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CsokobaDoc* CsokobaView::GetDocument() const // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CsokobaDoc)));
	return (CsokobaDoc*)m_pDocument;
}
#endif //_DEBUG


// CsokobaView message handlers
static int n=0;
void CsokobaView::buildmap()
{
	    Transitions();
    	step = 0;
		string v = CT2A(ReadMap(wethermap(n)).GetString());
		num_D = 0;
		// TODO: Add your implementation code here.
		FILE* s = freopen(v.c_str(), "r", stdin);
		//FILE* s = freopen("map001.txt", "r", stdin);
		char* a = new char[300];
		memset(map, 0, sizeof(map));
		memset(map1, 0, sizeof(map1));
		memset(mapD, 0, sizeof(mapD));
		int wL = 0;
		int line = 0;
		initializemap();
		CClientDC ad(this);
		CString D;
		while (fgets(a, 300, s)) {
			for (int j = 0; j < strlen(a); j++) {
				map[line][j] = a[j];//stroe origin map
				map1[line][j] = a[j];//update
				if (a[j] == 'C' || a[j] == 'D') {//store D
					mapD[line][j] = 1;
					num_D++;
				}
				D.Format(L"Destionation %d", num_D);
				ad.TextOut(500, 450, D);
				int x = j * 32;
				int y = line * 32;
				switch (a[j]) {
				case 'H':
					DrawBitma(IDB_BITMAP1, x, y);
					break;
				case 'B':
					DrawBitma(IDB_BITMAP5, x, y);
					break;
				case 'D':
					DrawBitma(IDB_BITMAP6, x, y);
					break;
				case 'W':
					DrawBitma(IDB_BITMAP2, x, y);
					posx = x; posy = y;
					wpx = line; wpy = j;
					break;
				case 'C':
					DrawBitma(IDB_BITMAP3, x, y);
					break;
				default:
					// Handle unknown characters if necessary
					break;
				}
			}
			line += 1;
		}
	
}


void CsokobaView::initializemap()
{
	// TODO: Add your implementation code here.
	for (int i = 0; i < 50; i++) {
		for (int j = 0; j < 50; j++) {
			CBitmap aBitmap;
			aBitmap.LoadBitmap(IDB_BITMAP4);
			CClientDC aDC(this);
			CDC memDC;
			memDC.CreateCompatibleDC(&aDC);
			memDC.SelectObject(&aBitmap);
			aDC.BitBlt(i * 32, j * 32, 50, 50, &memDC, 0, 0, SRCCOPY);
		}
	}
}

static int stepmusic = 1;
void CsokobaView::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags)
{
	Level(n);
	bool k1 = 0;
	if (nChar == 'W'||nChar=='H'|| nChar == '&') {
		if (stepmusic) { PlaySound(L"movebox.wav", NULL, SND_ASYNC); }
		else { PlaySound(NULL, NULL, SND_PURGE); }
		if (map1[wpx - 2][wpy] != 'H' && map1[wpx - 2][wpy] != 'B'&& map1[wpx - 2][wpy] != 'C') { k1 = 1; }
		if (map1[wpx - 1][wpy] == ' ' || map1[wpx - 1][wpy] == 'D') {
			drawnchr(nChar);
			step++;
			
		}
		else if ((map1[wpx-1][wpy] == 'B' || map1[wpx-1][wpy] == 'C') && k1) {
			step++;
			CBitmap hD; CBitmap B; CBitmap hL;
			CClientDC aDC(this);
			CDC memDC;
			memDC.CreateCompatibleDC(&aDC);
			//Box DESTINATION
			if (mapD[wpx - 2][wpy]) {
				B.LoadBitmap(IDB_BITMAP3);
				map1[wpx - 2][wpy] = 'C';
			}
			else {
				B.LoadBitmap(IDB_BITMAP5);
				map1[wpx - 2][wpy] = 'B';
			}
			memDC.SelectObject(&B);
			aDC.BitBlt(posx, posy - 64, 50, 50, &memDC, 0, 0, SRCCOPY);
			// human destionation
			hD.LoadBitmap(IDB_BITMAP2);
			memDC.SelectObject(&hD);
			posy -= 32;
			aDC.BitBlt(posx, posy, 50, 50, &memDC, 0, 0, SRCCOPY);
			//human leave
			if (mapD[wpx][wpy]) {
				hL.LoadBitmap(IDB_BITMAP6);
				map1[wpx][wpy] = 'D';
			}
			else {
				hL.LoadBitmap(IDB_BITMAP4);
				map1[wpx][wpy] = ' ';
			}
			memDC.SelectObject(&hL);
			aDC.BitBlt(posx, posy + 32, 50, 50, &memDC, 0, 0, SRCCOPY);
			wpx -= 1;
			map1[wpx][wpy] = 'W';
		}

	}
	if (nChar == 'D'||nChar == 'L'|| nChar == 39) {
		if (stepmusic) { PlaySound(L"movebox.wav", NULL, SND_ASYNC); }
		else { PlaySound(NULL, NULL, SND_PURGE); }
		if (map1[wpx][wpy + 2] != 'H' && map1[wpx][wpy + 2] != 'C' && map1[wpx][wpy + 2] != 'B') { k1 = 1; }
		if (map1[wpx][wpy + 1] == ' ' || map1[wpx][wpy + 1] == 'D') {
			drawnchr(nChar);
			step++;
		}
		else if ((map1[wpx][wpy + 1] == 'B' || map1[wpx][wpy + 1] == 'C') && k1) {
			step++;
			CBitmap hD; CBitmap B; CBitmap hL;
			CClientDC aDC(this);
			CDC memDC;
			memDC.CreateCompatibleDC(&aDC);
			//Box DESTINATION
			if (mapD[wpx][wpy + 2]) {
				B.LoadBitmap(IDB_BITMAP3);
				map1[wpx][wpy + 2] = 'C';
			}
			else {
				B.LoadBitmap(IDB_BITMAP5);
				map1[wpx][wpy + 2] = 'B';
			}
			memDC.SelectObject(&B);
			aDC.BitBlt(posx + 64, posy, 50, 50, &memDC, 0, 0, SRCCOPY);
			// human destionation
			hD.LoadBitmap(IDB_BITMAP2);
			memDC.SelectObject(&hD);
			posx += 32;
			aDC.BitBlt(posx, posy, 50, 50, &memDC, 0, 0, SRCCOPY);
			//human leave
			if (mapD[wpx][wpy]) {
				hL.LoadBitmap(IDB_BITMAP6);
				map1[wpx][wpy] = 'D';
			}
			else {
				hL.LoadBitmap(IDB_BITMAP4);
				map1[wpx][wpy] = ' ';
			}
			memDC.SelectObject(&hL);
			aDC.BitBlt(posx - 32, posy, 50, 50, &memDC, 0, 0, SRCCOPY);
			wpy += 1;
			map1[wpx][wpy] = 'W';
		}

	}
	if (nChar == 'A'|| nChar == 'K'||nChar=='%') {
		if (stepmusic) { PlaySound(L"movebox.wav", NULL, SND_ASYNC); }
		else { PlaySound(NULL, NULL, SND_PURGE); }
		if (map1[wpx][wpy - 2] != 'H'&& map1[wpx][wpy - 2] != 'B'&&map1[wpx][wpy - 2] != 'C') { k1 = 1; }
		if (map1[wpx][wpy - 1] == ' ' || map1[wpx][wpy - 1] == 'D') {
			drawnchr(nChar);
			step++;
		}
		else if ((map1[wpx][wpy - 1] == 'B' || map1[wpx][wpy - 1] == 'C') && k1 ) {
			step++;
			CBitmap hD; CBitmap B; CBitmap hL;
			CClientDC aDC(this);
			CDC memDC;
			memDC.CreateCompatibleDC(&aDC);
			//Box DESTINATION
			if (mapD[wpx][wpy - 2]) {
				B.LoadBitmap(IDB_BITMAP3);
				map1[wpx][wpy - 2] = 'C';
			}
			else {
				B.LoadBitmap(IDB_BITMAP5);
				map1[wpx][wpy - 2] = 'B';
			}
			memDC.SelectObject(&B);
			aDC.BitBlt(posx - 64, posy, 50, 50, &memDC, 0, 0, SRCCOPY);
			// human destionation
			hD.LoadBitmap(IDB_BITMAP2);
			memDC.SelectObject(&hD);
			posx -= 32;
			aDC.BitBlt(posx, posy, 50, 50, &memDC, 0, 0, SRCCOPY);
			//human leave
			if (mapD[wpx][wpy]) {
				hL.LoadBitmap(IDB_BITMAP6);
				map1[wpx][wpy] = 'D';
			}
			else {
				hL.LoadBitmap(IDB_BITMAP4);
				map1[wpx][wpy] = ' ';
			}
			memDC.SelectObject(&hL);
			aDC.BitBlt(posx + 32, posy, 50, 50, &memDC, 0, 0, SRCCOPY);
			wpy -= 1;
			map1[wpx][wpy] = 'W';
		}

	}
	if (nChar == 'S'|| nChar == 'J' || nChar == '(') {
		if (stepmusic) { PlaySound(L"movebox.wav", NULL, SND_ASYNC); }
		else { PlaySound(NULL, NULL, SND_PURGE); }
		bool k1 = 0;
		if (map1[wpx + 2][wpy] != 'H'&& map1[wpx + 2][wpy] != 'B'&& map1[wpx + 2][wpy] != 'C') { k1 = 1; }
		if (map1[wpx + 1][wpy] == ' ' || map1[wpx + 1][wpy] == 'D') {
			drawnchr(nChar);
			step++;
		}
		else if ((map1[wpx + 1][wpy] == 'B' || map1[wpx + 1][wpy] == 'C') && k1 ) {
			step++;
			CBitmap hD; CBitmap B; CBitmap hL;
			CClientDC aDC(this);
			CDC memDC;
			memDC.CreateCompatibleDC(&aDC);
			//Box DESTINATION
			if (mapD[wpx + 2][wpy]) {
				B.LoadBitmap(IDB_BITMAP3);
				map1[wpx + 2][wpy] = 'C';
			}
			else {
				B.LoadBitmap(IDB_BITMAP5);
				map1[wpx + 2][wpy] = 'B';
			}
			memDC.SelectObject(&B);
			aDC.BitBlt(posx, posy + 64, 50, 50, &memDC, 0, 0, SRCCOPY);
			// human destionation
			hD.LoadBitmap(IDB_BITMAP2);
			memDC.SelectObject(&hD);
			posy += 32;
			aDC.BitBlt(posx, posy, 50, 50, &memDC, 0, 0, SRCCOPY);
			//human leave
			if (mapD[wpx][wpy]) {
				hL.LoadBitmap(IDB_BITMAP6);
				map1[wpx][wpy] = 'D';
			}
			else {
				hL.LoadBitmap(IDB_BITMAP4);
				map1[wpx][wpy] = ' ';
			}
			memDC.SelectObject(&hL);
			aDC.BitBlt(posx, posy - 32, 50, 50, &memDC, 0, 0, SRCCOPY);
			wpx += 1;
			map1[wpx][wpy] = 'W';
		}
	}
	CClientDC ad(this);
	CString msg;
	msg.Format(L"STEPS %d",step);
	ad.TextOutW(500,500,msg);
	judWin();
	CView::OnKeyDown(nChar, nRepCnt, nFlags);

}


int CsokobaView::DrawD()
{
	// TODO: Add your implementation code here.
	return 0;
}


void CsokobaView::DrawS()
{
	// TODO: Add your implementation code here.
	
}


void CsokobaView::drawnchr(UINT nChar)
{
	CBitmap hL;
	CBitmap hD;
	CClientDC aDC(this);
	CDC memDC;
	memDC.CreateCompatibleDC(&aDC);
	if (mapD[wpx][wpy]) {
		hL.LoadBitmap(IDB_BITMAP6);
		map1[wpx][wpy] = 'D';
	}
	else {
		hL.LoadBitmap(IDB_BITMAP4);
		map1[wpx][wpy] = ' ';
	}
	memDC.SelectObject(&hL);
	aDC.BitBlt(posx, posy, 50, 50, &memDC, 0, 0, SRCCOPY);
	if (nChar == 'S'|| nChar == 'J' || nChar == '(') {
		posy+=32;
	}
	else if (nChar == 'D' || nChar == 'L'||nChar== 39) {
		posx += 32;
	}
	else if (nChar == 'W'|| nChar == 'H'||nChar == '&') {
		posy -= 32;
	}
	else if (nChar == 'A'|| nChar == 'K'||nChar == '%') {
		posx -= 32;
	}
	hD.LoadBitmap(IDB_BITMAP2);
	memDC.SelectObject(&hD);
	aDC.BitBlt(posx, posy, 50, 50, &memDC, 0, 0, SRCCOPY);
	if (nChar == 'S' || nChar == 'J'||nChar=='(') {
		wpx += 1;
	}
	else if (nChar == 'D'||nChar == 'L'||nChar == 39) {
		wpy+= 1;
	}
	else if (nChar == 'W' || nChar == 'H'||nChar == '&') {
		wpx -= 1;
	}
	else if (nChar == 'A' || nChar == 'K' || nChar == '%') {
		wpy -= 1;
	}
	map1[wpx][wpy] = 'W';
}


void CsokobaView::OnEditUndo()
{
	// TODO: Add your command handler code here
	
	buildmap();
	resettimere();
}


CString CsokobaView::ReadMap(int n)
{
	
	CString k; CString num;
	num.Format(L"%d", n);
	if (n == 0) {
		k = L"000";
	}
	else if (n < 10) {
		k = L"00" + num;
	}
	else if (n < 100) {
		k = L"0" + num;
	}
	else if (n < 151) {
		k = num;
	}
	CString file = L"map" + k + L".txt";
	return file;
	
	
}

static int time2 = 0;
void CsokobaView::judWin()
{
	// TODO: Add your implementation code here.
	mapL = 0;
	// TODO: Add your implementation code here.
	for (int i = 0; i < 50; i++) {
		for (int j = 0; j < 50; j++) {
			if (map1[i][j] == '\n') {
				break;
			}
			if (map1[i][j] == 'C') {
				mapL++;
			}
		}
	}
	CClientDC adc(this);
	CString mm;
	mm.Format(L"Arriavl %d", mapL);
	adc.TextOut(500, 475, mm);
	if (mapL == num_D) {
		adc.TextOut(500, 550, L"WIN");
		CString min, sec;
		if (time2) {
			min.Format(L"%02d", imin);
			sec.Format(L"%02d", isec);
			CString time = min + L" : " + sec;
			AfxMessageBox(L"Next LeveL\r\n�A��F " + time, MB_OK);
		}
		else {
			AfxMessageBox(L"Next LeveL", MB_OK);
		}
		n += 1;
		buildmap();
		isec = 0;
		imin = 0;
	}
}


void CsokobaView::Level(int n)
{
	// TODO: Add your implementation code here.
	CClientDC adc(this);
	CString numm;
	numm.Format(L"LEVEL %d", n);
	adc.TextOut(500, 425, numm);
}


void CsokobaView::Jwin(UINT nChar)
{
	

}


int CsokobaView::wethermap(int n)
{
	//debug

	int a1 = 0; int b = 0;
	string v = CT2A(ReadMap(n).GetString());
	FILE* s = freopen(v.c_str(), "r", stdin);
	char* a = new char[300];
	while (fgets(a, 300, s)) {
		for (int j = 0; j < strlen(a); j++) {
			//record map
			if (a[j] == 'B') {//store D
				a1++;
			}
			if (a[j] == 'D') {
				b++;
			}
		}
	}
	if (a1 != b) {
		return wethermap(n + 1);
	}
	else {
		return n;
	}
}


void CsokobaView::DrawBitma(int bitmapID, int x, int y)
{
	CBitmap aBitmap;
	aBitmap.LoadBitmap(bitmapID);
	CClientDC aDC(this);
	CDC memDC;
	memDC.CreateCompatibleDC(&aDC);
	memDC.SelectObject(&aBitmap);
	aDC.BitBlt(x, y, 50, 50, &memDC, 0, 0, SRCCOPY);
	// TODO: Add your implementation code here.
}

#include<windows.h>
//���
void CsokobaView::Transitions()
{
	/*
	for (int i = 0; i < 10; i++) {
	
			for (int j = 0; j < 10; j++) {
				CBitmap aBitmap;
				Sleep(100);
				aBitmap.LoadBitmap(IDB_BITMAP7);
				CClientDC aDC(this);
				CDC memDC;
				memDC.CreateCompatibleDC(&aDC);
				memDC.SelectObject(&aBitmap);
				aDC.BitBlt(i * 200, j * 200, 200, 200, &memDC, 0, 0, SRCCOPY);
			}
	}
	*/
}


void CsokobaView::OnSettingSkip()
{
	// TODO: Add your command handler code here
	AD ad;
	ad.DoModal();
	n += 1;
	resettimere();
    buildmap();
	
}


void CsokobaView::OnAdvancedTimer()
{
	SetTimer(1, 1000, NULL);
	buildmap();
	resettimere();
	time2 = 1;
}


void CsokobaView::OnTimer(UINT_PTR nIDEvent)
{
	// TODO: Add your message handler code here and/or call default
	CClientDC ad(this);
	// TODO: Add your message handler code here and/or call default
	isec += 1;
	CString min; CString sec;
	if (isec == 60) { isec = 0; imin += 1; }
	if (imin == 5) {
		KillTimer(1);
		AfxMessageBox(L"�W�L�ɶ��A����", MB_OK);
		buildmap();
		isec = 0;
		imin = 0;
	}
	min.Format(L"%02d", imin);
	sec.Format(L"%02d", isec);
	CString time = min + L":" + sec;
	ad.TextOut(850, 0, time);	
	CView::OnTimer(nIDEvent);
}


void CsokobaView::resettimere()
{
	isec = 0;
	imin = 0;
	// TODO: Add your implementation code here.
}


void CsokobaView::OnAdvancedStop()
{
	// TODO: Add your command handler code here
	time2 = 0;
	KillTimer(1);
	CBitmap aBitmap;
	aBitmap.LoadBitmap(IDB_BITMAP4);
	CClientDC aDC(this);
	CDC memDC;
	memDC.CreateCompatibleDC(&aDC);
	memDC.SelectObject(&aBitmap);
	for (int i = 0; i < 15; i +=10 ) {
		aDC.BitBlt(850+i, 0, 50, 50, &memDC, 0, 0, SRCCOPY);
	}

}

static int a = 0;
void CsokobaView::OnMusicBackground()
{
	PlaySound(L"hambuger.wav",NULL, SND_ASYNC);
	
	a = !a;
	//PlaySound(L"hambuger.wav", NULL, SND_ASYNC);
	// �ϥ� PlaySound ��Ƽ����n��
	if (a == 0) {
		//PlaySound(NULL, NULL, SND_PURGE);
		PlaySound( NULL, 0, SND_PURGE);
	}
	// TODO: Add your command handler code here

}


void CsokobaView::OnMusicElsemusic()
{
	stepmusic=!stepmusic;
}
