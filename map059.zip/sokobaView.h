
// sokobaView.h : interface of the CsokobaView class
//
#include"AD.h"
#pragma once
#include<string>

class CsokobaView : public CView
{
protected: // create from serialization only
	CsokobaView() noexcept;
	DECLARE_DYNCREATE(CsokobaView)

// Attributes
public:
	CsokobaDoc* GetDocument() const;

// Operations
public:

// Overrides
public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);

// Implementation
public:
	virtual ~CsokobaView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	DECLARE_MESSAGE_MAP()
public:
	void buildmap();
	int posx;
	int posy;
	int wpx;
	int wpy;
	void initializemap();
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	int DrawD();
	void DrawS();
	void drawnchr(UINT nChar);
	afx_msg void OnEditUndo();
	CString ReadMap(int n);
	void judWin();
	int num_D;
	int mapL;
	int mapW;
	int step;
	int times;
	void Level(int n);
	void Jwin(UINT nChar);
	int wethermap(int n);
	void DrawBitma(int bitmapID, int x, int y);
	void Transitions();
	afx_msg void OnSettingSkip();
	afx_msg void OnAdvancedTimer();
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	int isec;
	int imin;
	void resettimere();
	afx_msg void OnAdvancedStop();
	afx_msg void OnMusicBackground();
	afx_msg void OnMusicElsemusic();
};

#ifndef _DEBUG  // debug version in sokobaView.cpp
inline CsokobaDoc* CsokobaView::GetDocument() const
   { return reinterpret_cast<CsokobaDoc*>(m_pDocument); }
#endif

